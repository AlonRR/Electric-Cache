window.onload = function () {

  $(document).ready(function () {
    // Handle image click event
    $('.img-thumbnail').click(function () {
      const imagePath = $(this).attr('src');
      $('#lightbox-img').attr('src', imagePath);
    });

    // Clear image source when the modal is closed
    $('#lightboxModal').on('hidden.bs.modal', function () {
      $('#lightbox-img').attr('src', '');
    });
  });


  // let ctx = document.getElementById("myChart").getContext("2d");
  // let myChart = new Chart(ctx, {
  //   type: "line",
  //   data: {
  //     labels: [
  //       "10:00",
  //       "11:00",
  //       "12:00",
  //       "13:00",
  //       "14:00",
  //       "15:00",
  //       "16:00",
  //     ],
  //     datasets: [
  //       {
  //         label: "work load",
  //         data: [2, 9, 3, 17, 6, 3, 7],
  //         backgroundColor: "rgb(197, 197, 197,0.5)",
  //       },
  //       {
  //         label: "free hours",
  //         data: [2, 2, 5, 5, 2, 1, 10],
  //         backgroundColor: "rgb(245, 245, 245,0.7)",
  //       },
  //     ],
  //   },
  // });
  // var categories = ['Jan', 'Fab', 'Mar', 'Apr'];
  // var values = [25, 50, 75, 100];

  // var ctr = document.getElementById("myChart2");
  // var myChart2 = new Chart(ctr, {
  //   type: 'bar',
  //   data: {
  //     labels: ['Jan', 'Fab', 'Mar', 'Apr', 'Jun', 'Jul'],
  //     datasets: [
  //       {
  //         label: 'Savings',
  //         data: [105, 124, 78, 91, 62, 56],
  //         backgroundColor: ['rgba(255, 99, 132, 0.2)',
  //           'rgba(54, 162, 235, 0.2)',
  //           'rgba(255, 206, 86, 0.2)',
  //           'rgba(75, 192, 192, 0.2)',
  //           'rgba(153, 102, 255, 0.2)',
  //           'rgba(255, 159, 64, 0.2)'
  //         ],

  //         borderColor: [
  //           'rgba(255,99,132,1)',
  //           'rgba(54, 162, 235, 1)',
  //           'rgba(255, 206, 86, 1)',
  //           'rgba(75, 192, 192, 1)',
  //           'rgba(153, 102, 255, 1)',
  //           'rgba(255, 159, 64, 1)'
  //         ],
  //         borderWidth: 1
  //       }
  //     ]
  //   },
  //   options: {
  //     scales: {
  //       yAxes: [{
  //         ticks: {
  //           beginAtZero: true
  //         }
  //       }]
  //     }
  //   }
  // });


  // Get the context of the new chart canvas
  var ctxnew = document.getElementById('newChart').getContext('2d');

  // Set the chart data and options
  var chartData = {
    labels: ['Label 1', 'Label 2', 'Label 3'],  // Replace with your data labels
    datasets: [
      {
        label: 'Dataset 1',  // Replace with your dataset label
        data: [10, 20, 30],  // Replace with your dataset values
        backgroundColor: 'rgba(75, 192, 192, 0.2)',  // Replace with desired color
        borderColor: 'rgba(75, 192, 192, 1)',  // Replace with desired color
        borderWidth: 1
      }
    ]
  };

  var chartOptions = {
    // Set chart options as needed
  };

  // Create and render the new line chart
  new Chart(ctxnew, {
    type: 'line',
    data: chartData,
    options: chartOptions
  })


};


document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('edit-btn').addEventListener('click', function () {
    document.getElementById('viewMode').style.display = 'block';
    document.getElementById('editMode').style.display = 'block';
  });

  document.getElementById('save-btn').addEventListener('click', function () {
    document.getElementById('editMode').style.display = 'none';
    document.getElementById('viewMode').style.display = 'block';
  });
});

const submit = document.querySelector('#sumbmit');
const form = document.querySelector('#form');

// submit.addEventListener('click', (e) => {
//   e.preventDefault();
//   saveName();

// });

const saveName = async () => {
  try {
    let response = await fetch('action.php', {
      method: 'POST',
      body: new FormData(form),
    });
    const result = await response.json();
    console.log(result);
  } catch (erroe) {
    console.log(error);
  }
};

